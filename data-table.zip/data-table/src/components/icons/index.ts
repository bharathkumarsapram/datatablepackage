export { default as Loader } from '@components/icons/loader';
