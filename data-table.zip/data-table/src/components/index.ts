export {default as BVDataTable} from './BVDatatable';

